<?php
$servername = "abf3cb6dbc30";
$username = "root";
$password = "mypass";
$dbname = "glapp";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>